<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Welcome | Hospital CRM</title>

  <!-- Tailwind CSS -->
  <script src="https://cdn.tailwindcss.com"></script>

  <!-- Fonts & Icons -->
  <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600;700&display=swap" rel="stylesheet">
  <script src="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/js/all.min.js"></script>

  <style>
    :root {
      --primary: #0B717A;
      --light: #E8F9F9;
    }

    body {
      font-family: "Poppins", sans-serif;
      background: linear-gradient(135deg, #e7fbfb, #f5ffff);
      overflow-x: hidden;
    }

    @keyframes float {
      0%, 100% { transform: translateY(0); }
      50% { transform: translateY(-8px); }
    }
    @keyframes fadeIn {
      from { opacity: 0; transform: translateY(20px); }
      to { opacity: 1; transform: translateY(0); }
    }

    .fade-in { animation: fadeIn 1.5s ease forwards; opacity: 0; }
    .float { animation: float 4s ease-in-out infinite; }
    .glass {
      background: rgba(255, 255, 255, 0.8);
      backdrop-filter: blur(14px);
      border: 1px solid rgba(255, 255, 255, 0.3);
    }

    .navbar {
      background: rgba(255,255,255,0.9);
      backdrop-filter: blur(10px);
      position: fixed;
      top: 0; left: 0; right: 0;
      z-index: 50;
      border-bottom: 1px solid rgba(0,0,0,0.05);
    }
  </style>
</head>
<body class="text-gray-800">

  <!-- 🔹 NAVBAR -->
  <header class="navbar flex justify-between items-center px-8 py-4 shadow-sm">
    <div class="flex items-center gap-3">
      <i class="fa-solid fa-hospital text-[var(--primary)] text-3xl"></i>
      <h1 class="font-semibold text-xl text-[var(--primary)]">My Hospital CRM</h1>
    </div>
    <a href="<?php echo e(route('admin.login.form')); ?>" class="bg-[var(--primary)] text-white px-6 py-2 rounded-full shadow hover:bg-[#095f68] transition">
      Go to Dashboard →
    </a>
  </header>

  <!-- 🔹 HERO SECTION -->
  <section class="min-h-screen flex flex-col items-center justify-center text-center px-6 bg-gradient-to-br from-[#d9f9f9] to-white">
    <div class="fade-in max-w-4xl mt-20">
      <div class="mb-8">
        <div class="bg-[var(--primary)] inline-block p-6 rounded-full float shadow-xl">
          <i class="fa-solid fa-heart-pulse text-white text-5xl"></i>
        </div>
      </div>

      <h1 class="text-5xl font-bold text-[var(--primary)] mb-4">Welcome to My Hospital CRM</h1>
      <p class="text-gray-600 text-lg md:text-xl leading-relaxed mb-4">
        A modern, intelligent and secure platform to streamline your hospital operations, improve patient experiences, and empower your healthcare team.
      </p>
      <p class="text-[var(--primary)] font-medium text-lg italic mb-8">"Empowering Hospitals. Enhancing Care."</p>

      <a href="#features" class="bg-[var(--primary)] text-white px-8 py-4 rounded-full text-lg font-semibold shadow-lg hover:bg-[#095f68] hover:scale-105 transition-all duration-300">
        Explore Features ↓
      </a>
    </div>
  </section>

  <!-- 🔹 ABOUT SECTION -->
  <section class="py-20 px-8 bg-white">
    <div class="max-w-5xl mx-auto text-center">
      <h2 class="text-3xl font-semibold text-[var(--primary)] mb-6">What is Hospital CRM?</h2>
      <p class="text-gray-600 text-lg leading-relaxed">
        Hospital CRM is an all-in-one healthcare management ecosystem that helps administrators, doctors, nurses, and staff collaborate seamlessly. 
        It centralizes patient records, billing, and appointments, while providing real-time analytics to optimize hospital performance.
      </p>
    </div>
  </section>

  <!-- 🔹 FEATURES SECTION -->
  <section id="features" class="py-20 bg-[var(--light)]">
    <div class="max-w-6xl mx-auto px-6 text-center">
      <h2 class="text-3xl font-bold text-[var(--primary)] mb-12">Core Features</h2>

      <div class="grid md:grid-cols-3 gap-10">
        <div class="glass p-8 rounded-2xl hover:-translate-y-1 hover:shadow-lg transition-all duration-300">
          <i class="fa-solid fa-users text-[var(--primary)] text-4xl mb-4"></i>
          <h3 class="text-xl font-semibold mb-2">Patient Management</h3>
          <p class="text-gray-600 text-sm">Manage patient details, medical history, and reports from one secure dashboard.</p>
        </div>

        <div class="glass p-8 rounded-2xl hover:-translate-y-1 hover:shadow-lg transition-all duration-300">
          <i class="fa-solid fa-user-md text-[var(--primary)] text-4xl mb-4"></i>
          <h3 class="text-xl font-semibold mb-2">Doctor & Staff Coordination</h3>
          <p class="text-gray-600 text-sm">Smart scheduling, automated duty allocation, and inter-department communication.</p>
        </div>

        <div class="glass p-8 rounded-2xl hover:-translate-y-1 hover:shadow-lg transition-all duration-300">
          <i class="fa-solid fa-chart-line text-[var(--primary)] text-4xl mb-4"></i>
          <h3 class="text-xl font-semibold mb-2">Data Analytics</h3>
          <p class="text-gray-600 text-sm">Generate insightful analytics to enhance decision-making and resource efficiency.</p>
        </div>
      </div>
    </div>
  </section>

  <!-- 🔹 CONTACT SECTION -->
  <section class="py-20 bg-white text-center">
    <h2 class="text-3xl font-semibold text-[var(--primary)] mb-4">Need Support?</h2>
    <p class="text-gray-600 mb-8">We’re here to help with setup, training, or technical assistance anytime.</p>

    <div class="flex justify-center gap-6 flex-wrap">
      <a href="#" class="flex items-center gap-2 bg-[var(--primary)] text-white px-6 py-3 rounded-full shadow hover:bg-[#095f68] transition">
        <i class="fa-solid fa-envelope"></i> Email Us
      </a>
      <a href="#" class="flex items-center gap-2 bg-[var(--primary)] text-white px-6 py-3 rounded-full shadow hover:bg-[#095f68] transition">
        <i class="fa-solid fa-phone"></i> Contact Support
      </a>
    </div>
  </section>

  <!-- 🔹 FOOTER -->
  <footer class="bg-[var(--primary)] text-white py-6 text-center">
    <div class="flex justify-center gap-4 mb-2">
      <i class="fa-brands fa-facebook"></i>
      <i class="fa-brands fa-twitter"></i>
      <i class="fa-brands fa-linkedin"></i>
    </div>
    <p class="text-sm">&copy; 2025 My Hospital CRM | Built with ❤️ for Smarter Healthcare</p>
  </footer>
</body>
</html><?php /**PATH C:\xampp\htdocs\Bitmax\Hospital crm\resources\views/welcome.blade.php ENDPATH**/ ?>