<aside id="sidebar" class="w-64 fixed top-0 left-0 h-screen overflow-y-auto shadow-lg transition-all duration-300 sidebar-collapsed">
  <!-- Logo Section -->
  <div class="flex items-center justify-center px-4 py-4 border-b border-gray-200 dark:border-gray-700">
    <img src="{{ asset('image/Gemini_Generated_Image_xxqbl3xxqbl3xxqb.png') }}" alt="Dreams EMR Logo" class="w-8 h-8 dark:invert">
    <h1 class="text-xl font-bold sidebar-text ml-2">Dreams EMR</h1>
  </div>
  
  <!-- Main Navigation -->
  <nav class="p-4 space-y-3">
    <div>
      <p class="text-xs text-gray-600 dark:text-gray-400 font-semibold uppercase mb-1">Main</p>
      <a href="{{ route('admin.dashboard') }}" class="flex items-center space-x-2 px-3 py-2 rounded-md hover:bg-gray-200 dark:hover:bg-gray-700 {{ request()->routeIs('admin.dashboard') ? 'bg-gray-200 text-gray-900 dark:bg-primary dark:text-white' : '' }}">
        <i class="fas fa-tachometer-alt"></i>
        <span class="sidebar-text">Dashboard</span>
      </a>
    </div>
   
    <!-- Healthcare Section -->
    <div>
      <p class="text-xs text-gray-600 dark:text-gray-400 font-semibold uppercase mt-4 mb-1 sidebar-text">Healthcare</p>
      <a href="#" class="flex items-center space-x-2 px-3 py-2 rounded-md hover:bg-gray-200 dark:hover:bg-gray-700">
        <i class="fas fa-user-injured"></i>
        <span class="sidebar-text">Patients</span>
      </a>
      <a href="#" class="flex items-center space-x-2 px-3 py-2 rounded-md hover:bg-gray-200 dark:hover:bg-gray-700">
        <i class="fas fa-user-md"></i>
        <span class="sidebar-text">Doctors</span>
      </a>
      <a href="#" class="flex items-center space-x-2 px-3 py-2 rounded-md hover:bg-gray-200 dark:hover:bg-gray-700">
        <i class="fas fa-calendar-check"></i>
        <span class="sidebar-text">Appointments</span>
      </a>
      <a href="#" class="flex items-center space-x-2 px-3 py-2 rounded-md hover:bg-gray-200 dark:hover:bg-gray-700">
        <i class="fas fa-notes-medical"></i>
        <span class="sidebar-text">Visits</span>
      </a>
    </div>
   
    <!-- Manage Section -->
    <div>
      <p class="text-xs text-gray-600 dark:text-gray-400 font-semibold uppercase mt-4 mb-1 sidebar-text">Manage</p>
      <a href="{{ route('admin.ward-bed') }}" class="flex items-center space-x-2 px-3 py-2 rounded-md hover:bg-gray-200 dark:hover:bg-gray-700 {{ request()->routeIs('admin.ward-bed') ? 'bg-gray-200 text-gray-900 dark:bg-primary dark:text-white' : '' }}">
        <i class="fas fa-bed"></i>
        <span class="sidebar-text">Wards & Beds</span>
      </a>
      <a href="{{ route('admin.stock') }}" class="flex items-center space-x-2 px-3 py-2 rounded-md hover:bg-gray-200 dark:hover:bg-gray-700">
        <i class="fas fa-boxes"></i>
        <span class="sidebar-text">Stock</span>
      </a>
      <a href="#" class="flex items-center space-x-2 px-3 py-2 rounded-md hover:bg-gray-200 dark:hover:bg-gray-700">
        <i class="fas fa-users-cog"></i>
        <span class="sidebar-text">Staffs</span>
      </a>
      <a href="#" class="flex items-center space-x-2 px-3 py-2 rounded-md hover:bg-gray-200 dark:hover:bg-gray-700">
        <i class="fas fa-bell"></i>
        <span class="sidebar-text">Notifications</span>
      </a>
    </div>
  </nav>
</aside>