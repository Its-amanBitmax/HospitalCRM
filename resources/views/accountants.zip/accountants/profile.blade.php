@extends('layouts.accountant')

@section('content')
<div class="min-h-screen bg-gray-50 py-8">
    <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <!-- Profile Header -->
        <div class="bg-white shadow-xl rounded-lg overflow-hidden mb-8">
            <div class="h-32 bg-gradient-to-r from-blue-500 to-blue-600"></div>
            <div class="px-8 py-6 -mt-16 relative">
                <div class="flex flex-col md:flex-row items-start md:items-center justify-between">
                    <div class="flex items-center">
                        <div class="relative">
                            <div class="h-32 w-32 rounded-full border-4 border-white bg-gray-200 flex items-center justify-center shadow-lg">
                                @if($accountant->image)
                                    <img src="{{ asset('storage/' . $accountant->image) }}" 
                                         alt="{{ $accountant->name }}" 
                                         class="h-full w-full rounded-full object-cover">
                                @else
                                    <span class="text-4xl font-bold text-gray-600">
                                        {{ substr($accountant->name, 0, 1) }}
                                    </span>
                                @endif
                                <div class="absolute bottom-2 right-2 h-8 w-8 bg-green-500 rounded-full border-2 border-white flex items-center justify-center">
                                    <svg class="w-4 h-4 text-white" fill="currentColor" viewBox="0 0 20 20">
                                        <path fill-rule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clip-rule="evenodd"/>
                                    </svg>
                                </div>
                            </div>
                        </div>
                        <div class="ml-6">
                            <h1 class="text-3xl font-bold text-gray-900">{{ $accountant->name }}</h1>
                            <p class="text-gray-600 mt-1">{{ $accountant->email }}</p>
                            <p class="text-gray-500 mt-1">
                                <svg class="w-4 h-4 inline-block mr-1" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z"/>
                                </svg>
                                {{ $accountant->employee_code }}
                            </p>
                           
                        </div>
                    </div>
                    <div class="mt-4 md:mt-0">
                        <a href="#" 
                           class="inline-flex items-center px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white font-medium rounded-lg transition">
                            <svg class="w-4 h-4 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M11 5H6a2 2 0 00-2 2v11a2 2 0 002 2h11a2 2 0 002-2v-5m-1.414-9.414a2 2 0 112.828 2.828L11.828 15H9v-2.828l8.586-8.586z"/>
                            </svg>
                            Edit Profile
                        </a>
                    </div>
                </div>
            </div>
        </div>

        <!-- Main Content Grid -->
        <div class="grid grid-cols-1 lg:grid-cols-3 gap-8">
            <!-- Left Column -->
            <div class="lg:col-span-2 space-y-8">
                <!-- Personal Information -->
                <div class="bg-white shadow rounded-lg p-6">
                    <div class="flex items-center justify-between mb-6">
                        <h2 class="text-xl font-bold text-gray-900">Personal Information</h2>
                        <span class="text-sm text-gray-500">Employee ID: {{ $accountant->employee_code ?? 'N/A' }}</span>
                    </div>
                    <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                        <div class="space-y-4">
                            <div>
                                <label class="block text-sm font-medium text-gray-500">Full Name</label>
                                <p class="mt-1 text-gray-900 font-medium">{{ $accountant->name }}</p>
                            </div>
                            <div>
                                <label class="block text-sm font-medium text-gray-500">Email Address</label>
                                <p class="mt-1 text-gray-900 font-medium">{{ $accountant->email }}</p>
                            </div>
                            <div>
                                <label class="block text-sm font-medium text-gray-500">Phone Number</label>
                                <p class="mt-1 text-gray-900 font-medium">{{ $accountant->phone ?? 'Not provided' }}</p>
                            </div>
                            <div>
                                <label class="block text-sm font-medium text-gray-500">Date of Birth</label>
                                <p class="mt-1 text-gray-900 font-medium">
                                    {{ $accountant->date_of_birth ? \Carbon\Carbon::parse($accountant->date_of_birth)->format('d M, Y') : 'Not provided' }}
                                </p>
                            </div>
                        </div>
                        <div class="space-y-4">
                            <div>
                                <label class="block text-sm font-medium text-gray-500">Gender</label>
                                <p class="mt-1 text-gray-900 font-medium">{{ $accountant->gender ?? 'Not provided' }}</p>
                            </div>
                            <div>
                                <label class="block text-sm font-medium text-gray-500">Joining Date</label>
                                <p class="mt-1 text-gray-900 font-medium">
                                    {{ $accountant->hire_date ? \Carbon\Carbon::parse($accountant->hire_date)->format('d M, Y') : 'Not provided' }}
                                </p>
                            </div>
                            <div>
                                <label class="block text-sm font-medium text-gray-500">Department</label>
                                <p class="mt-1 text-gray-900 font-medium">
                                    {{ $accountant->department->department_name ?? 'Not assigned' }}
                                </p>
                            </div>
                            <div>
                                <label class="block text-sm font-medium text-gray-500">Account Status</label>
                                <span class="inline-flex items-center px-3 py-1 rounded-full text-sm font-medium 
                                    {{ $accountant->status == 'Active' ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800' }}">
                                    {{ $accountant->status }}
                                </span>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Address Information -->
                @if($accountant->addresses->isNotEmpty())
                <div class="bg-white shadow rounded-lg p-6">
                    <h2 class="text-xl font-bold text-gray-900 mb-6">Address Information</h2>
                    <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                        @foreach($accountant->addresses as $address)
                        <div class="border border-gray-200 rounded-lg p-4">
                            <div class="flex items-center justify-between mb-3">
                                <h3 class="font-medium text-gray-900 capitalize">{{ $address->address_type }} Address</h3>
                            </div>
                            <div class="space-y-2">
                                <p class="text-gray-700">{{ $address->street }}</p>
                                <p class="text-gray-700">{{ $address->city }}, {{ $address->state }}</p>
                                <p class="text-gray-700">{{ $address->country }} - {{ $address->postal_code }}</p>
                            </div>
                        </div>
                        @endforeach
                    </div>
                </div>
                @endif

                <!-- Professional Information -->
                @if($accountant->professions->isNotEmpty())
                <div class="bg-white shadow rounded-lg p-6">
                    <h2 class="text-xl font-bold text-gray-900 mb-6">Professional Information</h2>
                    <div class="space-y-4">
                        @foreach($accountant->professions as $profession)
                        <div class="border-l-4 border-blue-500 pl-4 py-2">
                            <div class="flex justify-between items-start">
                                <div>
                                    <h3 class="font-bold text-gray-900">{{ $profession->title }}</h3>
                                    @if($profession->department)
                                        <p class="text-gray-700">Department: {{ $profession->department->department_name }}</p>
                                    @endif
                                </div>
                            </div>
                        </div>
                        @endforeach
                    </div>
                </div>
                @endif

                <!-- Family Details -->
                @if($accountant->familyDetails->isNotEmpty())
                <div class="bg-white shadow rounded-lg p-6">
                    <h2 class="text-xl font-bold text-gray-900 mb-6">Family Details</h2>
                    <div class="overflow-x-auto">
                        <table class="min-w-full divide-y divide-gray-200">
                            <thead class="bg-gray-50">
                                <tr>
                                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Name</th>
                                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Relation</th>
                                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Date of Birth</th>
                                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Contact</th>
                                </tr>
                            </thead>
                            <tbody class="bg-white divide-y divide-gray-200">
                                @foreach($accountant->familyDetails as $family)
                                <tr class="hover:bg-gray-50">
                                    <td class="px-6 py-4 whitespace-nowrap">
                                        <div class="text-sm font-medium text-gray-900">{{ $family->name }}</div>
                                    </td>
                                    <td class="px-6 py-4 whitespace-nowrap">
                                        <span class="px-2 py-1 text-xs font-medium rounded-full bg-blue-100 text-blue-800 capitalize">
                                            {{ $family->relationship }}
                                        </span>
                                    </td>
                                    <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                                        {{ $family->date_of_birth ? \Carbon\Carbon::parse($family->date_of_birth)->format('d M, Y') : 'N/A' }}
                                    </td>
                                    <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                                        {{ $family->contact_number ?? 'N/A' }}
                                    </td>
                                </tr>
                                @endforeach
                            </tbody>
                        </table>
                    </div>
                </div>
                @endif
            </div>

            <!-- Right Column -->
            <div class="space-y-8">
                <!-- Payroll Information -->
                @if($accountant->payroll)
                <div class="bg-white shadow rounded-lg p-6">
                    <h2 class="text-xl font-bold text-gray-900 mb-6">Payroll Information</h2>
                    <div class="space-y-4">
                        <div class="flex justify-between items-center">
                            <span class="text-gray-600">Salary</span>
                            <span class="font-bold text-gray-900">₹{{ number_format($accountant->payroll->salary, 2) }}</span>
                        </div>
                        <div class="flex justify-between items-center">
                            <span class="text-gray-600">Payment Frequency</span>
                            <span class="font-medium text-gray-900">{{ $accountant->payroll->payment_frequency }}</span>
                        </div>
                        <div class="border-t pt-4">
                            <div class="flex justify-between items-center">
                                <span class="text-lg font-bold text-gray-900">Bank Details</span>
                            </div>
                            <div class="mt-2 space-y-2">
                                <p class="text-sm"><span class="font-medium">Bank:</span> {{ $accountant->payroll->bank_name }}</p>
                                <p class="text-sm"><span class="font-medium">Account:</span> {{ $accountant->payroll->bank_account }}</p>
                                <p class="text-sm"><span class="font-medium">IFSC:</span> {{ $accountant->payroll->ifsc_code }}</p>
                                @if($accountant->payroll->upi_number)
                                    <p class="text-sm"><span class="font-medium">UPI:</span> {{ $accountant->payroll->upi_number }}</p>
                                @endif
                                @if($accountant->payroll->pf_number)
                                    <p class="text-sm"><span class="font-medium">PF Number:</span> {{ $accountant->payroll->pf_number }}</p>
                                @endif
                            </div>
                        </div>
                    </div>
                </div>
                @endif

                <!-- Qualifications -->
                @if($accountant->qualifications->isNotEmpty())
                <div class="bg-white shadow rounded-lg p-6">
                    <h2 class="text-xl font-bold text-gray-900 mb-6">Qualifications</h2>
                    <div class="space-y-4">
                        @foreach($accountant->qualifications as $qualification)
                        <div class="border border-gray-200 rounded-lg p-4">
                            <h3 class="font-bold text-gray-900">{{ $qualification->degree }}</h3>
                            <p class="text-gray-700 text-sm">{{ $qualification->institution }}</p>
                            <div class="mt-2">
                                <span class="text-xs text-gray-500">
                                    Completed: {{ $qualification->year_completed }}
                                </span>
                            </div>
                        </div>
                        @endforeach
                    </div>
                </div>
                @endif

                <!-- Documents -->
                @if($accountant->documents->isNotEmpty())
                <div class="bg-white shadow rounded-lg p-6">
                    <div class="flex items-center justify-between mb-6">
                        <h2 class="text-xl font-bold text-gray-900">Documents</h2>
                        <span class="text-sm text-gray-500">{{ $accountant->documents->count() }} files</span>
                    </div>
                    <div class="space-y-3">
                        @foreach($accountant->documents as $document)
                        <div class="flex items-center justify-between p-3 bg-gray-50 rounded-lg hover:bg-gray-100 transition">
                            <div class="flex items-center">
                                <div class="p-2 bg-blue-100 rounded-lg mr-3">
                                    <svg class="w-5 h-5 text-blue-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z"/>
                                    </svg>
                                </div>
                                <div>
                                    <p class="text-sm font-medium text-gray-900 truncate max-w-xs">
                                        {{ $document->document_type }}
                                    </p>
                                    <p class="text-xs text-gray-500">
                                        Uploaded: {{ \Carbon\Carbon::parse($document->uploaded_at)->format('d M, Y') }}
                                    </p>
                                </div>
                            </div>
                            <a href="{{ asset('storage/' . $document->document_path) }}" 
                               target="_blank"
                               class="text-blue-600 hover:text-blue-800 p-1">
                                <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 12a3 3 0 11-6 0 3 3 0 016 0z"/>
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M2.458 12C3.732 7.943 7.523 5 12 5c4.478 0 8.268 2.943 9.542 7-1.274 4.057-5.064 7-9.542 7-4.477 0-8.268-2.943-9.542-7z"/>
                                </svg>
                            </a>
                        </div>
                        @endforeach
                    </div>
                </div>
                @endif

                <!-- Specialities -->
                @if($accountant->specialities && $accountant->specialities->isNotEmpty())
                <div class="bg-white shadow rounded-lg p-6">
                    <h2 class="text-xl font-bold text-gray-900 mb-6">Specialities</h2>
                    <div class="space-y-4">
                        @foreach($accountant->specialities as $speciality)
                        <div class="border border-gray-200 rounded-lg p-4">
                            <div class="flex justify-between items-center">
                                <div>
                                    <h3 class="font-bold text-gray-900">{{ $speciality->speciality->name ?? 'Speciality' }}</h3>
                                    <p class="text-gray-700 text-sm">{{ $speciality->proficiency_level }}</p>
                                </div>
                                <div class="text-right">
                                    <span class="text-xs font-medium px-2 py-1 rounded-full bg-green-100 text-green-800">
                                        {{ $speciality->years_of_experience }} years
                                    </span>
                                </div>
                            </div>
                        </div>
                        @endforeach
                    </div>
                </div>
                @endif

                <!-- Contact Information -->
                <div class="bg-white shadow rounded-lg p-6">
                    <h2 class="text-xl font-bold text-gray-900 mb-6">Contact Information</h2>
                    <div class="space-y-4">
                        <div class="flex items-center">
                            <div class="p-2 bg-gray-100 rounded-lg mr-3">
                                <svg class="w-5 h-5 text-gray-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 8l7.89 4.26a2 2 0 002.22 0L21 8M5 19h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z"/>
                                </svg>
                            </div>
                            <div>
                                <p class="text-sm text-gray-500">Email</p>
                                <p class="font-medium text-gray-900">{{ $accountant->email }}</p>
                            </div>
                        </div>
                        @if($accountant->phone)
                        <div class="flex items-center">
                            <div class="p-2 bg-gray-100 rounded-lg mr-3">
                                <svg class="w-5 h-5 text-gray-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 5a2 2 0 012-2h3.28a1 1 0 01.948.684l1.498 4.493a1 1 0 01-.502 1.21l-2.257 1.13a11.042 11.042 0 005.516 5.516l1.13-2.257a1 1 0 011.21-.502l4.493 1.498a1 1 0 01.684.949V19a2 2 0 01-2 2h-1C9.716 21 3 14.284 3 6V5z"/>
                                </svg>
                            </div>
                            <div>
                                <p class="text-sm text-gray-500">Phone</p>
                                <p class="font-medium text-gray-900">{{ $accountant->phone }}</p>
                            </div>
                        </div>
                        @endif
                        @if($accountant->emergency_contact)
                        <div class="flex items-center">
                            <div class="p-2 bg-red-100 rounded-lg mr-3">
                                <svg class="w-5 h-5 text-red-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M18.364 5.636l-3.536 3.536m0 5.656l3.536 3.536M9.172 9.172L5.636 5.636m3.536 9.192l-3.536 3.536M21 12a9 9 0 11-18 0 9 9 0 0118 0zm-5 0a4 4 0 11-8 0 4 4 0 018 0z"/>
                                </svg>
                            </div>
                            <div>
                                <p class="text-sm text-gray-500">Emergency Contact</p>
                                <p class="font-medium text-gray-900">{{ $accountant->emergency_contact }}</p>
                            </div>
                        </div>
                        @endif
                    </div>
                </div>

                <!-- Quick Stats -->
                <div class="bg-white shadow rounded-lg p-6">
                    <h2 class="text-xl font-bold text-gray-900 mb-6">Account Overview</h2>
                    <div class="grid grid-cols-2 gap-4">
                        <div class="bg-blue-50 rounded-lg p-4 text-center">
                            <p class="text-2xl font-bold text-blue-600">
                                {{ $accountant->hire_date ? \Carbon\Carbon::parse($accountant->hire_date)->diffInYears(now()) : 0 }}
                            </p>
                            <p class="text-sm text-gray-600 mt-1">Years Experience</p>
                        </div>
                        <div class="bg-green-50 rounded-lg p-4 text-center">
                            <p class="text-2xl font-bold text-green-600">
                                {{ $accountant->qualifications->count() }}
                            </p>
                            <p class="text-sm text-gray-600 mt-1">Qualifications</p>
                        </div>
                        <div class="bg-purple-50 rounded-lg p-4 text-center">
                            <p class="text-2xl font-bold text-purple-600">
                                {{ $accountant->professions->count() }}
                            </p>
                            <p class="text-sm text-gray-600 mt-1">Professions</p>
                        </div>
                        <div class="bg-yellow-50 rounded-lg p-4 text-center">
                            <p class="text-2xl font-bold text-yellow-600">
                                {{ $accountant->documents->count() }}
                            </p>
                            <p class="text-sm text-gray-600 mt-1">Documents</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Styles -->
<style>
    .animate-fade-in {
        animation: fadeIn 0.5s ease-in-out;
    }
    
    @keyframes fadeIn {
        from {
            opacity: 0;
            transform: translateY(10px);
        }
        to {
            opacity: 1;
            transform: translateY(0);
        }
    }
    
    .hover-lift {
        transition: transform 0.2s ease;
    }
    
    .hover-lift:hover {
        transform: translateY(-2px);
    }
</style>

<!-- JavaScript for Interactive Elements -->
<script>
    document.addEventListener('DOMContentLoaded', function() {
        // Add animation to cards
        const cards = document.querySelectorAll('.bg-white.shadow');
        cards.forEach((card, index) => {
            card.style.animationDelay = `${index * 0.1}s`;
            card.classList.add('animate-fade-in');
        });

        // Add hover effects to interactive elements
        const interactiveElements = document.querySelectorAll('a, button, .hover-lift');
        interactiveElements.forEach(element => {
            element.classList.add('hover-lift');
        });

        // Smooth scroll for internal links
        document.querySelectorAll('a[href^="#"]').forEach(anchor => {
            anchor.addEventListener('click', function (e) {
                e.preventDefault();
                const target = document.querySelector(this.getAttribute('href'));
                if (target) {
                    target.scrollIntoView({
                        behavior: 'smooth',
                        block: 'start'
                    });
                }
            });
        });
    });
</script>
@endsection