<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::table('appointments', function (Blueprint $table) {
            $table->enum('type', ['consultation', 'Appointment'])->default('Appointment')->change();
            $table->enum('subtype', ['by voicecall', 'by chat', 'by video call'])->nullable()->after('type');
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::table('appointments', function (Blueprint $table) {
            $table->dropColumn('subtype');
            $table->enum('type', ['Appointment', 'consultation'])->default('Appointment')->change();
        });
    }
};
