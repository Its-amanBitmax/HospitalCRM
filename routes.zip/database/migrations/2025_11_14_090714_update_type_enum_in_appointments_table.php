<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::table('appointments', function (Blueprint $table) {
            $table->enum('type', ['Appointment', 'Consultant Oncall', 'Consultant Onchat', 'Consultant OnVideo'])->default('Appointment')->change();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::table('appointments', function (Blueprint $table) {
            $table->enum('type', ['Appointment', 'Video Consultation'])->default('Appointment')->change();
        });
    }
};
